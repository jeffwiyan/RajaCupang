

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
  <h2 class="mb-4">Seller Ikan Cupang</h2>

  <form method="GET" class="mb-4">
    <div class="row">
      <div class="col-md-4">
        <select name="category" class="form-select">
          <option value="">Semua Jenis</option>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cat->name); ?>" <?php echo e(request('category') == $cat->name ? 'selected' : ''); ?>>
              <?php echo e($cat->name); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-4">
        <select name="sort" class="form-select">
          <option value="">Urutkan Harga</option>
          <option value="termurah" <?php echo e(request('sort') == 'termurah' ? 'selected' : ''); ?>>Termurah</option>
          <option value="termahal" <?php echo e(request('sort') == 'termahal' ? 'selected' : ''); ?>>Termahal</option>
        </select>
      </div>
      <div class="col-md-4">
        <button class="btn btn-primary w-100">Filter</button>
      </div>
    </div>
  </form>

  <div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="col-md-3 mb-4">
        <div class="card h-100">
          <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title"><?php echo e($product->name); ?></h5>
            <p class="card-text">Rp<?php echo e(number_format($product->price)); ?></p>

            <?php if($product->stock > 0): ?>
              <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-outline-primary mb-2 w-100">
                Lihat Detail
              </a>
            <?php else: ?>
              <span class="badge bg-danger mb-2 text-center w-100">Stok Habis</span>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
              <form action="<?php echo e(route('wishlist.toggle', $product->id)); ?>" method="POST" class="mt-auto">
                <?php echo csrf_field(); ?>
                <button class="btn btn-outline-danger btn-sm w-100" type="submit">
                  <i class="fa<?php echo e(auth()->user()->wishlist->contains($product->id) ? 's' : 'r'); ?> fa-heart"></i>
                  <?php echo e(auth()->user()->wishlist->contains($product->id) ? 'Hapus dari Wishlist' : 'Tambah ke Wishlist'); ?>

                </button>
              </form>
            <?php endif; ?>

          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class="text-center">Produk tidak ditemukan.</p>
    <?php endif; ?>
  </div>

  <div class="d-flex justify-content-center">
    <?php echo e($products->withQueryString()->links()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\raja-cupang\resources\views/seller/home.blade.php ENDPATH**/ ?>