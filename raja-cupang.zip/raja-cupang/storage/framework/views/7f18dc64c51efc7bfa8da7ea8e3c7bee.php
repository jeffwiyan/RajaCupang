

<?php $__env->startSection('content'); ?>
<div class="container mt-4 mb-5">
  <div class="row">
    <div class="col-md-5">
      <?php if($product->image): ?>
        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="img-fluid rounded" alt="<?php echo e($product->name); ?>">
      <?php else: ?>
        <div class="text-muted">Gambar tidak tersedia</div>
      <?php endif; ?>
    </div>
    <div class="col-md-7">
      <h2><?php echo e($product->name); ?></h2>

      <p>
        <strong>Harga:</strong>
        Rp<?php echo e(number_format($product->price ?? 0, 0, ',', '.')); ?>

      </p>

      <p>
        <strong>Stok:</strong>
        <?php echo e($product->stock ?? '0'); ?>

      </p>

      <p><?php echo e($product->description ?? 'Tidak ada deskripsi.'); ?></p>

      <?php if(($product->stock ?? 0) > 0): ?>
        <a 
          href="https://wa.me/62895321002181?text=Halo%20admin,%20saya%20ingin%20order%20ikan%20<?php echo e(urlencode($product->name)); ?>"
          class="btn btn-success mt-3"
          target="_blank"
        >
          <i class="fab fa-whatsapp"></i> Pesan via WhatsApp
        </a>
      <?php else: ?>
        <div class="mt-3">
          <span class="badge bg-danger">Stok Habis</span>
        </div>
      <?php endif; ?>
    </div>
  </div>

  
  <div class="mt-5">
    <h4>Review Pengguna</h4>

    
    <?php if(auth()->guard()->check()): ?>
      <form action="<?php echo e(route('review.store', $product->id)); ?>" method="POST" class="mb-4">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label for="rating" class="form-label">Rating (1-5)</label>
          <input type="number" name="rating" id="rating" class="form-control" min="1" max="5" required value="<?php echo e(old('rating')); ?>">
        </div>
        <div class="mb-3">
          <label for="comment" class="form-label">Komentar</label>
          <textarea name="comment" id="comment" rows="3" class="form-control"><?php echo e(old('comment')); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Kirim Review</button>
      </form>
    <?php endif; ?>

    
    <?php if($product->reviews->count()): ?>
      <?php $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="border rounded p-3 mb-2">
          <strong><?php echo e($review->user->name); ?></strong> —
          <span class="text-warning">
            <?php for($i = 0; $i < $review->rating; $i++): ?>
              ★
            <?php endfor; ?>
          </span>
          <p class="mb-0"><?php echo e($review->comment); ?></p>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
      <p class="text-muted">Belum ada review untuk produk ini.</p>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\raja-cupang\resources\views/product-detail.blade.php ENDPATH**/ ?>