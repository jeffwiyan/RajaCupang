

<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
  <div class="alert alert-success">
    <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>
<div class="container py-4">
  <h4>Wishlist Saya</h4>
  <div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="col-md-4 mb-3">
        <div class="card h-100">
          <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
          <div class="card-body d-flex flex-column">
            <h5><?php echo e($product->name); ?></h5>
            <p>Rp <?php echo e(number_format($product->price)); ?></p>

            <a href="<?php echo e(route('product.show', $product)); ?>" class="btn btn-sm btn-outline-primary mb-2 w-100">
              Lihat Detail
            </a>

            <form action="<?php echo e(route('wishlist.toggle', $product->id)); ?>" method="POST" class="mt-auto">
              <?php echo csrf_field(); ?>
              <button class="btn btn-sm btn-danger w-100">Hapus dari Wishlist</button>
            </form>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p>Kamu belum menambahkan produk ke wishlist.</p>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\raja-cupang\resources\views/wishlist/index.blade.php ENDPATH**/ ?>